public class LinkedListTest {

    public static void main(String[] args) {
        System.out.println("Creating linked list...");
        MyLinkedList list = new MyLinkedList();
        System.out.println("Adding nodes A B C D using addNode(Node n): ");
        Node n = new Node("A");
        list.addNode(n);
        n = new Node("B");
        list.addNode(n);
        n = new Node("C");
        list.addNode(n);
        n = new Node("D");
        list.addNode(n);
        System.out.println("List contents: ");
        list.printList();

        System.out.println("\nTesting insertBefore(int index, Node n): ");
        System.out.println("Inserting X before A");
        n = new Node("X");
        list.insertBefore(0, n);

        System.out.println("List contents: ");
        list.printList();

        System.out.println("Inserting Y before D");
        n = new Node("Y");
        list.insertBefore(4, n);

        System.out.println("List contents: ");
        list.printList();

        System.out.println("Inserting Z before B");
        n = new Node("Z");
        list.insertBefore(2, n);

        System.out.println("List contents: ");
        list.printList();

        System.out.println("\nTesting insertAfter(int index, Node n): ");
        System.out.println("Inserting 2 after A");
        n = new Node("2");
        list.insertAfter(list.indexOf("A"), n);
        System.out.println("List contents: ");
        list.printList();
        System.out.println("Inserting 21 after D");
        n = new Node("21");
        list.insertAfter(list.indexOf("D"), n);
        System.out.println("List contents: ");
        list.printList();/Users/juelabreu/Desktop/\

        System.out.println("\nTesting indexOf(String str): ");
        System.out.println("index of X: " + list.indexOf("X"));
        System.out.println("index of A: " + list.indexOf("A"));
        System.out.println("index of D: " + list.indexOf("D"));
        System.out.println("index of 21: " + list.indexOf("21"));
        
        
        System.out.println("\nTesting removeNodeAt(int index) : ");
        System.out.println("Removing X ");list.removeNodeAt(list.indexOf("X"));
        list.printList();
        System.out.println("Removing 21 ");list.removeNodeAt(list.indexOf("21"));
        list.printList();
        System.out.println("Removing Z ");list.removeNodeAt(list.indexOf("Z"));
        list.printList();

    }
}
