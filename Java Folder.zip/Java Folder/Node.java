class Node {

    public String name;
    public Node next;

    Node() {
    }

    Node(String s) {
        this.name = s;
    }
}