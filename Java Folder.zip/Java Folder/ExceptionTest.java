public class ExceptionTest {

public static void throwMyException() throws MyException {
	throw new MyException("throwing MyException in method");
	
}

public static void main(String[] ags) {

throwMyException();
System.out.println("After throwMyException()");

	}  catch(MyException me) {
	System.out.println(me.getMsg());
	} catch(Exception e) {
		
	} finally {
		System.out.println("In finally block");
		
		
		}

	}

	
	