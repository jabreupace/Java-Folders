class MyLinkedList {

    private Node head;

    MyLinkedList() {
    }

    public void addNode(Node n) {
        if (head == null) {
            head = n;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = n;
        }
    }

    public void printList() {
// print each element in the LinkedList
        Node current = head;
        while (current != null) {
            System.out.print(current.name + " ");
            current = current.next;
        }
        System.out.println("");
    }

    public void insertBefore(int index, Node n) {
// adds Node n before index value
        if (index == 0) {
            n.next = head;
            head = n;
        } else {
            int i = 0;
            Node current = head;
            Node pre = null;
            while (current != null) {
                if (i == index) {
                    break;
                }
                pre = current;
                current = current.next;
                i++;
            }
            pre.next = n;
            n.next = current;
        }
    }

    public void insertAfter(int index, Node n) {
// adds Node n after index value 
        //insertBefore(index + 1, n);

        int i = 0;
        Node current = head;

        while (current != null) {
            if (i == index) {
                break;
            }

            current = current.next;
            i++;
        }
        if (current != null) {
            //
            Node nxt = current.next;
            current.next = n;
            n.next = nxt;
        }

    }

    public int indexOf(String str) {
//returns index of where String str  is at.  Returns -1 if String str
        //is not in LinkedList 
        int index = 0;

        Node current = head;

        while (current != null) {
            if (current.name.equalsIgnoreCase(str)) {
                return index;
            }
            current = current.next;
            index++;
        }
        return -1;
    }

    public void removeNodeAt(int index) {
// removes Node at index value  
        if (index == 0) {
            if (head != null) {
                head = head.next;
            } else {
                head = null;
            }

        } else {
            int i = 0;
            Node current = head;
            Node pre = null;
            while (current != null) {
                if (i == index) {
                    break;
                }
                pre = current;
                current = current.next;
                i++;
            }
            //if last
            if (current == null) {
                pre.next = null;
            } else {
                pre.next = current.next;
            }
        }
    }
}