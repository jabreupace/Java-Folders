public class Account {

   private int id;
   private double balance;

   Account() {
      System.out.println("in Account() constructor");
   }

   Account(double amt) {
      System.out.println("in Account(double amt) constructor");
      balance = amt;
   }

   Account(int myId, double balance) {
      System.out.println("in Account(int myId, double bal) constructor");
      id = myId;
      this.balance = balance;
   }

   public double getBalance() {
     return this.balance;
   }

   public void setBalance(double amt) {
     this.balance = amt;
   }

   public void deposit(double amt) {
      this.balance = this.balance + amt;
   }

   public void withdraw(double amt) throws MyException {
     if (amt <= balance)
       this.balance = this.balance - amt;
else 
throw new MyException(“Overdrawn Amount”);
   }

}