public class SpeakerMain {

    
    public static void main(String[] args) {
        Speaker speaker1 = new PoliticalSpeaker("Democrat");
        speaker1.speak();
        speaker1.announce("I'll make your life easy if you vote for me");

        System.out.println("");
        Speaker speaker2 = new MotivationalSpeaker();
        speaker2.speak();
        speaker2.announce("and enjoy!");

        System.out.println("");
        Speaker speaker3 = new Instructor();
        speaker3.speak();
        speaker3.announce("Java");

    }

}




