import java.util.Scanner;


public class PersonalInformationDriver {
    public static void main(String[] args) {
          
        display("Enter information for instance 1: \n");
        PersonalInformation p1 = createPersonalInformation();
        display("Enter information for instance 2: \n");
        PersonalInformation p2 = createPersonalInformation();
        display("Enter information for instance 3: \n");
        PersonalInformation p3 = createPersonalInformation();
        
        
        display("\n");
        
        display("Instance 1 information:");
        displayPersonalInformation(p1);
        display("Instance 2 information:");
        displayPersonalInformation(p2);
        display("Instance 3 information:");
        displayPersonalInformation(p3);
    }
    
   
     public static void displayPersonalInformation (PersonalInformation info) {
         display("\nName: "+info.getName());
         display("\nAddress: "+info.getAddress());
         display("\nAge: "+info.getName());
         display("\nPhoneNumber: "+info.getPhoneNumber());
         display("\n");
     }
    
   
    public static PersonalInformation createPersonalInformation() {
        PersonalInformation pi = new PersonalInformation();
        pi.setName(getString("Enter name: "));
        pi.setAddress(getString("Enter address: "));
        pi.setAge(getInt("Enter age: "));
        pi.setPhoneNumber(getString("Enter PhoneNumber: "));
        return pi;
    }
    
    public static String getString(String msg) {
        display(msg);
        Scanner input = new Scanner(System.in);
        return input.nextLine();
    }
    
     
    public static void display(String msg) {
        System.out.print(msg);
    }
    
      
    public static int getInt(String msg) {
        display(msg);
        Scanner input = new Scanner(System.in);
        return input.nextInt();
    }
}


