public class AnimalInterface {

public static void main(String[] args) {
 
Human h=new Human();
h.speak();

Dog d = new Dog();
d.speak();


System.out.println("Interface data type:");
Speaker s;
s =h;
s.speak();
s= d;
s.speak();

Walker w;
w = h;
w.walk();
w=d;
w.walk();

System.out.println(" **** Noahs Ark");
ArrayList<Walker> noahArk = newArrayList<Walker>();
noahArk.add(new Human());
noahArk.add(new Dog());
noahArk.add(new Bird());

for(int i=0; i<noahArk.size(); i++){
	Walker wk = noahArk.get(i);
	wk.walk();
}
} }
