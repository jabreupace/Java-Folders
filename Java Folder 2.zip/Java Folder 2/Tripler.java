import java.rmi.*;

public interface Tripler extends Remote {
	public int triple(int v) throws RemoteException;
}
