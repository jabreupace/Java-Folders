/*
 another class represent surgeon
should be a subclass of Doctor
 */
public class Surgeon extends Doctor {

    //anew instance variable operating
    //which indicates the surgeon is on operating or not.
    private boolean operating;

    public Surgeon(String name, int number, String specialty, boolean operating) {
        super(name, number, specialty);
        this.operating = operating;
    }

    public boolean isOperating() {
        return operating;
    }

    public void setOperating(boolean operating) {
        this.operating = operating;
    }

    @Override
    public String toString() {
        return super.toString() + " Operating:" + operating;
    }

    @Override
    public void work() {
        System.out.print(this.getName() + " works for the hospital. ");
        if (operating) {
            System.out.println(this.getName() + " is a operating now.");
        } else {
            System.out.println(this.getName() + " is not operating now.");
        }
    }

}
