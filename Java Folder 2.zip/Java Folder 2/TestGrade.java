import java.util.Scanner;

/*
 
 */
public class TestGrade {

    
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the number of grades to input: ");
        int size = input.nextInt();
        int values[] = new int[size];
        
        for (int i = 0; i < size; i++) {
            System.out.print("Enter grade " + (i + 1) + ":  ");
            values[i] = input.nextInt();
            
        }
        
        Grades grades = new Grades(values);
        System.out.println("");
        System.out.println("Number of grades: " + grades.numOfGrades());
        System.out.println("Lowest: " + grades.lowest());
        System.out.println("Highest: " + grades.highest());
        System.out.println("Average: " + grades.average());
        System.out.println("Number of failing grades(<60) : " + grades.numOfFailingGrades(60));
        System.out.println("Histogram: ");
        grades.histogram();
    }
}
