public interface Speaker {
  public void speak();
  public void announce( String str );

}