public class Instructor implements Speaker {
 

   
    public void speak() {
        System.out.println("I am an Instructor. ");
    }

    
    public void announce(String subject) {
        System.out.println("I teach " + subject );
    }

}