class Grades {

    private int[] values;

    Grades() {
    }

    Grades(int[] myArray) {
        setValues(myArray);
    }

    public void setValues(int[] myArray) {

        values = myArray;
    }

    public int[] getValues() {

        return values;
    }

    public int highest() {

        int maxScore = values[0];
        for (int i = 0; i < values.length; i++) {
            if (maxScore < values[i]) {
                maxScore = values[i];
            }
        }
        return maxScore;

    }

    ;
  public int lowest() {

        int minScore = values[0];
        for (int i = 0; i < values.length; i++) {
            if (minScore > values[i]) {
                minScore = values[i];
            }
        }
        return minScore;

    }

    ;
  public int numOfGrades() {
 
        return values.length;
    }

    ;
  public double average() {

        double sum = 0;
        for (int i = 0; i < values.length; i++) {
            sum += values[i];
        }
        return sum / values.length;
    }

    ;
  public int numOfFailingGrades(int gradeValue) {

        int count = 0;
        for (int i = 0; i < values.length; i++) {
            if (values[i] < gradeValue) {
                count++;
            }
        }
        return count;
    }

    public void histogram() {

        int count[] = new int[5];
        String range[] = {"90 – 100 | ", "80 – 89  | ", "70 – 79  | ", "60 – 69  | ", "< 60     | "};
        for (int i = 0; i < values.length; i++) {
            if (values[i] >= 90 && values[i] <= 100) {
                count[0]++;
            } else if (values[i] >= 80 && values[i] <= 89) {
                count[1]++;
            } else if (values[i] >= 70 && values[i] <= 79) {
                count[2]++;
            } else if (values[i] >= 60 && values[i] <= 69) {
                count[3]++;
            } else {
                count[4]++;
            }
        }

        for (int i = 0; i < count.length; i++) {
            System.out.print(range[i]);
            for (int j = 0; j < count[i]; j++) {
                System.out.print("*");
            }
            System.out.println("");
        }
    }

}
