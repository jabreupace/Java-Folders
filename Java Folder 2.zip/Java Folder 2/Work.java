public void work()   
{      
System.out.println (name + " works for the hospital.");   
}