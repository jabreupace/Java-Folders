public class Student {
	
	int id;
	int midtermExam;
	int finalExam;
	
	double calcAvg() {
		double return_value;
		
		return_value = (midtermExam + finalExam) / 2.0;
		
		return return_value;
		
		
	
	}
	 char getletterGrade() {
	 	 char letterGrade; 
	 	 
	 	 double avg;
	 	 avg = calcAvg();
	 	 
	 	 if (avg >= 90)
	 	  letterGrade='A';
	 	 else if (avg >= 80)
	 	  letterGrade='B';
	 	 else if (avg >=70)
	 	  letterGrade='C';
	 	 else 
	 	  letterGrade='f';
	 	 
	  return letterGrade;
}
}
