* To run this tripler RMI project:

	 >javac TriplerImpl.java
	 >javac Client.java
	 >rmic -v1.2 TriplerImpl
	 >start rmiregistry
	 >start java TriplerImpl
	 >java Client 4  [optional server URL or IP]
*/
import java.rmi.*;
import java.rmi.server.*;

public class TriplerImpl extends UnicastRemoteObject
	 implements Tripler {
		 public TriplerImpl() throws RemoteException {
			 super();
		 }

		 public int triple(int v) {
			 System.err.println("Triple " + v);
			 return 3*v;
		 }
		 public static void main(String[] args) throws Exception {
			 System.err.println("Initializing server, ...");
			 TriplerImpl server = new TriplerImpl();
			 Naming.rebind("//localhost/Tripler", server);
			 System.err.println("Tripler server is up and running.");
		 }
}

