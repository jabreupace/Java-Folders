public class PartTime extends Employee {
private int hour;
private int rate;

PartTime() {
	PartTime(String S)
public void setHour(int h) {
hour = h;
}

public int getHour() {
return hour;
}
public int setRate(int r) {
rate = r;

}
public int getRate() {
return rate;
  }
  public int pay() {
  	  System.out.println("PartTime:pay()");
  	  return ( (hour*rate) + super.pay() );
  	 }
}