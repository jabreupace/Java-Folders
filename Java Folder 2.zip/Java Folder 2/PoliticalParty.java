/*
 PoliticalSpeaker
 */
public class PoliticalSpeaker implements Speaker{

    //Democrat or Republican
    private String party;

    public PoliticalSpeaker(String party) {
        this.party = party;
    }
    
    
    public void speak() {
        System.out.println("I am PoliticalSpeaker. I am "+party);
    }

   
    public void announce(String str) {
        System.out.println( str);
    }

}
