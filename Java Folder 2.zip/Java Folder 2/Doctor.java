/*
 subclass of HospitalEmployee
 */
public class Doctor extends HospitalEmployee{
//a new instance variable for specialty
    private String specialty;

    public Doctor( String name, int number,String specialty) {
        super(name, number);
        this.specialty = specialty;
    }

    public String getSpecialty() {
        return specialty;
    }

    public void setSpecialty(String specialty) {
        this.specialty = specialty;
    }

    @Override
    public String toString() {
        return super.toString()+  " " + specialty ;
    }
    
     @Override
    public void work() {
        super.work();
        System.out.println(this.getName() + " is a(n) "+ specialty  + " doctor.");
    }
    
}
