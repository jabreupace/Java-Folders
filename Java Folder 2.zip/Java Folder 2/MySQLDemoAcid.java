import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.*; 

/**
* @author JAbreu Sample of JDBC for MySQL ACID is implemented
*/

public class MySQLDemoACID {

 public static void main(String[] args) throws SQLException, IOException, ClassNotFoundException {

   // Load the MySQL driver
   Class.forName("com.mysql.jdbc.Driver");

   // Connect to the database
   Connection conn = DriverManager
       .getConnection("jdbc:mysql://localhost:3306/mydatabase");

   // For atomicity
   conn.setAutoCommit(false);

   // For isolation
   conn.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);

   Statement Stmt = null;
   Statement Stmt2 = null;
   try {
     String query = "delete from Stock where prod = 'p1'";
     PreparedStatement Stmt01 = conn.prepareStatement(query);
     Stmt01.setInt(1, 3);
     Stmt01.execute();

     String query2 = "delete from Product where prod = 'p1'";
     PreparedStatement Stmt02 = conn.prepareStatement(query);
     Stmt02.setInt(1, 3);

     Stmt02.execute();
     conn.close();
     
   } catch (SQLException e) {
     System.out.println("catch Exception");
     // For atomicity
     conn.rollback();
     Stmt.close();
     Stmt2.close();
     conn.close();
     return;
   } // main
   conn.commit();
   Stmt.close();
   Stmt2.close();
   conn.close();
 }
}