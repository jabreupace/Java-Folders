public class PoliticalSpeaker implements Speaker{
private String party;
    
    public PoliticalSpeaker(String party) {
this.party=party;
}
   @Override
    public void speak() {
        System.out.println(“I am PoliticalSpeaker. I am “+party);
    }

    @Override
    public void announce(String str) {
        System.out.println(str);
    }

}