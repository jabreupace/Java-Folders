public class MotivationalSpeaker implements Speaker{

    
    
   
    public void speak() {
        System.out.println("I am MotivationalSpeaker. ");
    }

    
    public void announce(String str) {
        System.out.println("I have only one thing to say....live happily"+" "+str);
    }

}