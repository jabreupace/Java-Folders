import java.rmi.*;

public class Client {
	public static void main(String[] args) throws Exception {
		String host = "localhost";
		if (args.length > 1)
			host = args[1];
		String objectName = "//" + host + "/Tripler";
		Tripler server = (Tripler)Naming.lookup(objectName);
		int triplee;
		if (args.length > 0) 
			triplee = java.lang.Integer.valueOf(args[0]).intValue();
		else { 
			triplee = 12;
			System.out.println("Using default value of " + triplee);
		}
		int answer = server.triple(triplee);
		System.out.println (triplee + " * 3 = " + answer);
	}
}
